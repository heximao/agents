---
name: s6-gateway-troubleshooting
description: "Troubleshooting Hermes Gateway instances running under s6 supervision in containerized environments."
version: 1.0.0
author: Assistant
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [gateway, s6, containers, troubleshooting, docker, profiles]
---

# Troubleshooting Gateway Under s6

In containerized environments (like Docker), Hermes uses `s6-overlay` to supervise processes. By default, running `hermes gateway run` detects the s6 environment and redirects execution to the supervisor (via `s6-svc`).

## Common Pitfall: "Another local Hermes gateway is already using this Feishu app_id"
If multiple gateways (e.g. `default` and a custom profile like `jin-jiancheng`) are started, they may try to bind to the same WebSocket (like Feishu). You must stop the default gateway before starting a new profile with the same credentials.

## Common Pitfall: "Gateway already running (PID XXXX)"
This happens when `gateway run` is executed but another instance is already bound to the session lock or port.
If using `--replace`, but the replacement hangs or times out, it is often due to the supervisor trying to infinitely respawn the *old* process while the new process is waiting for the lock.

## How to Register and Manage Profile Gateways Programmatically with S6ServiceManager

If you want the profiles (such as `coder`, `jin-jiancheng`, `xiajie`) to run under s6's supervision instead of manually running them with `--no-supervise`, you can register them programmatically using `S6ServiceManager` from `hermes_cli.service_manager`. This is the cleanest containerized solution.

### Verification and status inspection
```bash
# Check supervised dynamic profile status
/opt/hermes/.venv/bin/python3 -c "
from hermes_cli.service_manager import S6ServiceManager
mgr = S6ServiceManager()
print({p: mgr.is_running(mgr._service_name(p)) for p in mgr.list_profile_gateways()})
"
```

### Starting / Registering supervised profile gateways
To programmatically register and start supervised dynamic services:
```bash
# Register a profile (e.g. 'coder') and trigger s6 auto-start
/opt/hermes/.venv/bin/python3 -c "
from hermes_cli.service_manager import S6ServiceManager
mgr = S6ServiceManager()
# List registered
registered = mgr.list_profile_gateways()
if 'coder' not in registered:
    mgr.register_profile_gateway('coder')
else:
    # Start it if already registered but stopped
    mgr.start(mgr._service_name('coder'))
"
```

## How Profile Gateway Auto-Start Works (container_boot.py)

On every container boot, `/etc/cont-init.d/02-reconcile-profiles` runs `hermes_cli.container_boot.reconcile_profile_gateways()`. This module:

1. Reads `$HERMES_HOME/gateway_state.json` (root profile) and `$HERMES_HOME/profiles/<name>/gateway_state.json` (named profiles)
2. Recreates s6 service directories under `/run/service/gateway-<profile>/`
3. Auto-starts ONLY profiles whose `gateway_state` field is in `_AUTOSTART_STATES`
4. Profiles not in `_AUTOSTART_STATES` are registered in the `down` state (a `down` marker file is created)

**The state machine:**
- `"running"` → auto-started (default behavior)
- `"draining"` → was running, container shut down mid-shutdown → should auto-start (requires code fix, see below)
- `"stopped"` → explicitly stopped by user or crashed → registered but NOT started
- `None` / missing file → registered but NOT started (except legacy `gateway run` containers which get migrated to `"running"`)

**Boot log:** `$HERMES_HOME/logs/container-boot.log` records every reconciliation pass. Check this first when profiles don't auto-start.

### Common Pitfall: "draining" state prevents auto-restart after container reboot

When `docker stop` sends SIGTERM to the container, s6 forwards it to all supervised gateways. The gateway's graceful shutdown handler updates `gateway_state.json` to `"draining"`. If the container exits before the gateway finishes shutting down, the state stays `"draining"`. On next boot, the reconciler sees `"draining"` (not in `_AUTOSTART_STATES = frozenset({"running"})`), registers the profile but does NOT start it.

**Symptom:** A profile that was running before `docker restart` never comes back up. `container-boot.log` shows `prior_state=draining action=registered`.

**Fix:** Add `"draining"` to `_AUTOSTART_STATES` in `/opt/hermes/hermes_cli/container_boot.py`:
```python
# Line 36, change:
_AUTOSTART_STATES = frozenset({"running"})
# To:
_AUTOSTART_STATES = frozenset({"running", "draining"})
```

This is safe because `"draining"` is a shutdown transient — it means "was running, is shutting down gracefully". If the container restarts, the intent was clearly to keep it running.

**Note:** This fix is in the container image. It will be lost on `docker build`. Submit upstream or bake into the Dockerfile.

### Quick diagnostics

```bash
# Check what state each profile was in at last boot
cat /opt/data/hermes/logs/container-boot.log | tail -20

# Check current gateway_state.json for each profile
for f in /opt/data/gateway_state.json /opt/data/hermes/profiles/*/gateway_state.json; do
  echo "=== $f ==="; cat "$f" 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'state={d.get(\"gateway_state\")}')" 2>/dev/null || echo "(missing)"
done

# Manually trigger reconciliation (dry-run)
/opt/hermes/.venv/bin/python3 -c "
from hermes_cli.container_boot import reconcile_profile_gateways
from pathlib import Path
actions = reconcile_profile_gateways(hermes_home=Path('/opt/data'), scandir=Path('/run/service'), dry_run=True)
for a in actions: print(f'{a.profile}: prior={a.prior_state} -> {a.action}')
"
```

## How to bypass s6 supervision for manual debugging or profile gateways profile gateways

When working with custom profiles that are NOT statically registered with s6, `hermes gateway start/stop/restart` will fail with "no such gateway". 

To manually start a gateway for a specific profile and explicitly bypass the s6 supervisor loop:

```bash
# First, ensure the profile's gateway isn't already running in a zombie state
ps aux | grep "gateway run"

# **CRITICAL**: If you are trying to run a gateway for a non-default profile, you MUST set HERMES_HOME to the profile directory, not just HERMES_PROFILE. Otherwise, the gateway will read the default config.yaml and .env, causing port/websocket conflicts (e.g. Feishu "already in use").

# Run it directly in the background, bypassing s6, with explicit HERMES_HOME:
HERMES_HOME=/opt/data/hermes/profiles/<profile_name> /opt/hermes/.venv/bin/hermes gateway run --no-supervise --accept-hooks
```

**Crucial flags:**
- `--no-supervise`: Tells Hermes NOT to bounce the command to `s6-svc`. If you omit this in a container, it will recursively dispatch `gateway start`, fail (because the profile isn't registered with s6), and exit.
- `--accept-hooks`: Bypasses TTY prompts for shell hooks, allowing it to start cleanly in the background.

**Note on `--replace`**: 
Do NOT use `--replace` in combination with `--no-supervise` when you are launching manual custom profile gateways via `HERMES_HOME`. The `--replace` logic uses `s6` shutdown signals and often deadlocks or enters a restart loop with background tasks. If a process is stuck, use `ps aux` to find it and `kill -9` the specific PID before starting the new instance.