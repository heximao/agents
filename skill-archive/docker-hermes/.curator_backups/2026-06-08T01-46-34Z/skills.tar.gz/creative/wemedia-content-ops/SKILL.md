---
name: wemedia-content-ops
description: "Manage and execute automated content operations and workspace conventions for WeChat Official Accounts (WeMedia)."
version: 1.0.0
author: 金渐成 (Hermes Agent)
metadata:
  hermes:
    tags: [wemedia, wechat, content-ops, automation, workspace-conventions]
    category: creative
---

# WeMedia Content Operations & Workspace Conventions

This skill governs the structure, organization, and execution of automated content generation within the WeMedia self-media project. It ensures that content agents operate safely within the environment constraints and adhere to the project's strict modular configuration architecture.

## Workspace & Environment Principles

### 1. No Absolute Paths in Shared Configuration
* **Pitfall:** Do not write absolute environment paths (e.g., `/opt/wemedia` or `/opt/data/...`) into codebase-shared files like `CLAUDE.md` or `AGENTS.md`.
* **Reason:** The project runs inside Docker containers where absolute host paths are fluid or isolated. Hardcoded paths break portability.
* **Practice:** Learn environment paths via system inspection, store them in the agent's persistent memory (using the `memory` tool), and use relative paths for in-code operations.

### 2. CLAUDE.md as the Single Source of Truth
* **Principle:** Standardize on `CLAUDE.md` as the primary configuration entry point. 
* **Action:** Avoid keeping redundant generic files like `AGENTS.md`. Merge core objectives into `CLAUDE.md`.

### 3. Modular Role and Author Structuring
* **Convention:** Do not bloat `CLAUDE.md` with detailed author descriptions, style guides, or personal bios.
* **Practice:** Write dedicated author/role profiles to a modular sub-path:
  `./account/公众号/{公众号名称}/作者信息.md`
* **Reference:** Create a clean, relative reference pointer in `CLAUDE.md` to guide the agent to load the correct author profile when running.

---

## Writing & Execution Workflow

### Step 1: Initialize Identity
Before drafting any post or executing a content workflow:
1. Load `CLAUDE.md` to identify the active context.
2. Follow the pointer to `./account/公众号/{公众号名称}/作者信息.md` to load the active author profile (e.g., "金渐成", "天玑", "野人").
3. Apply style-specific skills and reference style guides (such as `references/jin-jiancheng-style.md` for Jin Jiancheng / Tianji style guidelines, or the global `humanizer` skill) depending on the author persona.

---

## Author Style Guides & References
For specific active author personas and their detailed writing conventions, refer to the following local reference files:
* **Jin Jiancheng (金渐成 / 天玑):** `references/jin-jiancheng-style.md` (detailed guidelines for no-AI rhythm, eliminating metaphors/logical connectives, anti-fragility philosophical tone, and flat friendly structure).

### Step 2: Content Draft Structuring
All daily investment analyses or general opinion posts should be structured cleanly:
- **No-AI Rhythm:** Follow 1-3 short sentence paragraphs. Use high margins/whitespaces.
- **No-AI Polish:** Strip away filler words, robotic transition markers, and empty headers. Apply the `humanizer` checklist.
- **Philosophy and Realism:** Connect micro-tactical execution (exact percentages, accounts, and tools) directly to pragmatic philosophy (e.g., Taleb's *Antifragile* or traditional classics), bypassing empty hype.

### Step 3: File Output and Archiving
Save the final polished article in the standard directory format:
`./Derived/{Year}/{Year}-{Month}/公众号/{公众号名称}/{Date}_{Topic}_content.md`
